#!/bin/sh
# NightLion v2
printf "\033]4;0;#4c4c4c;1;#bb0000;2;#04f623;3;#f3f167;4;#64d0f0;5;#ce6fdb;6;#00dadf;7;#bbbbbb;8;#555555;9;#ff5555;10;#7df71d;11;#ffff55;12;#62cbe8;13;#ff9bf5;14;#00ccd8;15;#ffffff\007"
printf "\033]10;#bbbbbb;#171717;#bbbbbb\007"
printf "\033]17;#b5d5ff\007"
printf "\033]19;#000000\007"
printf "\033]5;0;#e3e3e3\007"
