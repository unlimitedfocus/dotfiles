#!/bin/sh
# Whimsy
printf "\033]4;0;#535178;1;#ef6487;2;#5eca89;3;#fdd877;4;#65aef7;5;#aa7ff0;6;#43c1be;7;#ffffff;8;#535178;9;#ef6487;10;#5eca89;11;#fdd877;12;#65aef7;13;#aa7ff0;14;#43c1be;15;#ffffff\007"
printf "\033]10;#b3b0d6;#29283b;#b3b0d6\007"
printf "\033]17;#3d3c58\007"
printf "\033]19;#ffffff\007"
printf "\033]5;0;#ffffff\007"
