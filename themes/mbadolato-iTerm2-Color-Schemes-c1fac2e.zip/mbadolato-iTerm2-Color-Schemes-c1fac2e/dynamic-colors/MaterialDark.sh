#!/bin/sh
# MaterialDark
printf "\033]4;0;#212121;1;#b7141f;2;#457b24;3;#f6981e;4;#134eb2;5;#560088;6;#0e717c;7;#efefef;8;#424242;9;#e83b3f;10;#7aba3a;11;#ffea2e;12;#54a4f3;13;#aa4dbc;14;#26bbd1;15;#d9d9d9\007"
printf "\033]10;#e5e5e5;#232322;#16afca\007"
printf "\033]17;#dfdfdf\007"
printf "\033]19;#3d3d3d\007"
printf "\033]5;0;#b7141f\007"
