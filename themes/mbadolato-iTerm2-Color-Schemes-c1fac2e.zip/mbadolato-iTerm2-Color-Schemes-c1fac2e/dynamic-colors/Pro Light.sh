#!/bin/sh
# Pro Light
printf "\033]4;0;#000000;1;#e5492b;2;#50d148;3;#c6c440;4;#3b75ff;5;#ed66e8;6;#4ed2de;7;#dcdcdc;8;#9f9f9f;9;#ff6640;10;#61ef57;11;#f2f156;12;#0082ff;13;#ff7eff;14;#61f7f8;15;#f2f2f2\007"
printf "\033]10;#191919;#ffffff;#4d4d4d\007"
printf "\033]17;#c1ddff\007"
printf "\033]19;#191919\007"
printf "\033]5;0;#191919\007"
