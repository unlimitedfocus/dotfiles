#!/bin/sh
# IC_Orange_PPL
printf "\033]4;0;#000000;1;#c13900;2;#a4a900;3;#caaf00;4;#bd6d00;5;#fc5e00;6;#f79500;7;#ffc88a;8;#6a4f2a;9;#ff8c68;10;#f6ff40;11;#ffe36e;12;#ffbe55;13;#fc874f;14;#c69752;15;#fafaff\007"
printf "\033]10;#ffcb83;#262626;#fc531d\007"
printf "\033]17;#c14020\007"
printf "\033]19;#ffc88a\007"
printf "\033]5;0;#fafaff\007"
