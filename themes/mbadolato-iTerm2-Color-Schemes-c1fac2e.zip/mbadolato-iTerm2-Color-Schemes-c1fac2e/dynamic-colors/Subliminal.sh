#!/bin/sh
# Subliminal
printf "\033]4;0;#7f7f7f;1;#e15a60;2;#a9cfa4;3;#ffe2a9;4;#6699cc;5;#f1a5ab;6;#5fb3b3;7;#d4d4d4;8;#7f7f7f;9;#e15a60;10;#a9cfa4;11;#ffe2a9;12;#6699cc;13;#f1a5ab;14;#5fb3b3;15;#d4d4d4\007"
printf "\033]10;#d4d4d4;#282c35;#c7c7c7\007"
printf "\033]17;#484e5b\007"
printf "\033]19;#ffffff\007"
printf "\033]5;0;#ffffff\007"
