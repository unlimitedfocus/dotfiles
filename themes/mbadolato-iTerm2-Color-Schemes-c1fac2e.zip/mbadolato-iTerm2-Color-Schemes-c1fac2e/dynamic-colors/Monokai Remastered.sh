#!/bin/sh
# Monokai Remastered
printf "\033]4;0;#1a1a1a;1;#f4005f;2;#98e024;3;#fd971f;4;#9d65ff;5;#f4005f;6;#58d1eb;7;#c4c5b5;8;#625e4c;9;#f4005f;10;#98e024;11;#e0d561;12;#9d65ff;13;#f4005f;14;#58d1eb;15;#f6f6ef\007"
printf "\033]10;#d9d9d9;#0c0c0c;#fc971f\007"
printf "\033]17;#343434\007"
printf "\033]19;#ffffff\007"
printf "\033]5;0;#ebebeb\007"
