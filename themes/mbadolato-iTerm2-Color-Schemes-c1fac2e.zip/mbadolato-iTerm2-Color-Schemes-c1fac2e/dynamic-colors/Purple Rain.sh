#!/bin/sh
# Purple Rain
printf "\033]4;0;#000000;1;#ff260e;2;#9be205;3;#ffc400;4;#00a2fa;5;#815bb5;6;#00deef;7;#ffffff;8;#565656;9;#ff4250;10;#b8e36e;11;#ffd852;12;#00a6ff;13;#ac7bf0;14;#74fdf3;15;#ffffff\007"
printf "\033]10;#fffbf6;#21084a;#ff271d\007"
printf "\033]17;#287691\007"
printf "\033]19;#ffffff\007"
printf "\033]5;0;#333333\007"
