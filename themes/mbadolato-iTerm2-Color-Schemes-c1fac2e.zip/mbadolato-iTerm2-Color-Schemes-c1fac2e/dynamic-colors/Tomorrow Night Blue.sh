#!/bin/sh
# Tomorrow Night Blue
printf "\033]4;0;#000000;1;#ff9da4;2;#d1f1a9;3;#ffeead;4;#bbdaff;5;#ebbbff;6;#99ffff;7;#ffffff;8;#000000;9;#ff9da4;10;#d1f1a9;11;#ffeead;12;#bbdaff;13;#ebbbff;14;#99ffff;15;#ffffff\007"
printf "\033]10;#ffffff;#002451;#ffffff\007"
printf "\033]17;#003f8e\007"
printf "\033]19;#ffffff\007"
printf "\033]5;0;#ffffff\007"
