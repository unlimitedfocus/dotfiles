#!/bin/sh
# Obsidian
printf "\033]4;0;#000000;1;#a60001;2;#00bb00;3;#fecd22;4;#3a9bdb;5;#bb00bb;6;#00bbbb;7;#bbbbbb;8;#555555;9;#ff0003;10;#93c863;11;#fef874;12;#a1d7ff;13;#ff55ff;14;#55ffff;15;#ffffff\007"
printf "\033]10;#cdcdcd;#283033;#c0cad0\007"
printf "\033]17;#3e4c4f\007"
printf "\033]19;#dfe1e2\007"
printf "\033]5;0;#ffffff\007"
