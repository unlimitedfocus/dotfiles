#!/bin/sh
# Fideloper
printf "\033]4;0;#292f33;1;#cb1e2d;2;#edb8ac;3;#b7ab9b;4;#2e78c2;5;#c0236f;6;#309186;7;#eae3ce;8;#092028;9;#d4605a;10;#d4605a;11;#a86671;12;#7c85c4;13;#5c5db2;14;#819090;15;#fcf4df\007"
printf "\033]10;#dbdae0;#292f33;#d4605a\007"
printf "\033]17;#efb8ac\007"
printf "\033]19;#ffffff\007"
printf "\033]5;0;#6b7c7c\007"
