#!/bin/sh
# OceanicMaterial
printf "\033]4;0;#000000;1;#ee2b2a;2;#40a33f;3;#ffea2e;4;#1e80f0;5;#8800a0;6;#16afca;7;#a4a4a4;8;#777777;9;#dc5c60;10;#70be71;11;#fff163;12;#54a4f3;13;#aa4dbc;14;#42c7da;15;#ffffff\007"
printf "\033]10;#c2c8d7;#1c262b;#b3b8c3\007"
printf "\033]17;#6dc2b8\007"
printf "\033]19;#c2c8d7\007"
printf "\033]5;0;#ffffff\007"
