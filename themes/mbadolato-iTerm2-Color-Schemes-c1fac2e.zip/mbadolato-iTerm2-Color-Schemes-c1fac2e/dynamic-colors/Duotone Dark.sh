#!/bin/sh
# Duotone Dark
printf "\033]4;0;#1f1d27;1;#d9393e;2;#2dcd73;3;#d9b76e;4;#ffc284;5;#de8d40;6;#2488ff;7;#b7a1ff;8;#353147;9;#d9393e;10;#2dcd73;11;#d9b76e;12;#ffc284;13;#de8d40;14;#2488ff;15;#eae5ff\007"
printf "\033]10;#b7a1ff;#1f1d27;#ff9839\007"
printf "\033]17;#353147\007"
printf "\033]19;#b7a2ff\007"
printf "\033]5;0;#b7a2ff\007"
