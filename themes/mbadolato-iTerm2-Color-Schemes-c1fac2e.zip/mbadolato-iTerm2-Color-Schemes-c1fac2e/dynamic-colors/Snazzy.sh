#!/bin/sh
# Snazzy
printf "\033]4;0;#000000;1;#fc4346;2;#50fb7c;3;#f0fb8c;4;#49baff;5;#fc4cb4;6;#8be9fe;7;#ededec;8;#555555;9;#fc4346;10;#50fb7c;11;#f0fb8c;12;#49baff;13;#fc4cb4;14;#8be9fe;15;#ededec\007"
printf "\033]10;#ebece6;#1e1f29;#e4e4e4\007"
printf "\033]17;#81aec6\007"
printf "\033]19;#000000\007"
printf "\033]5;0;#f6f6f6\007"
