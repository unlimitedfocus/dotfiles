#!/bin/sh
# Teerb
printf "\033]4;0;#1c1c1c;1;#d68686;2;#aed686;3;#d7af87;4;#86aed6;5;#d6aed6;6;#8adbb4;7;#d0d0d0;8;#1c1c1c;9;#d68686;10;#aed686;11;#e4c9af;12;#86aed6;13;#d6aed6;14;#b1e7dd;15;#efefef\007"
printf "\033]10;#d0d0d0;#262626;#e4c9af\007"
printf "\033]17;#4d4d4d\007"
printf "\033]19;#ffffff\007"
printf "\033]5;0;#e5e5e5\007"
