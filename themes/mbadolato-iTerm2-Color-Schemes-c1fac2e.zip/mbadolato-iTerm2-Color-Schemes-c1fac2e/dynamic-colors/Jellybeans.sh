#!/bin/sh
# Jellybeans
printf "\033]4;0;#929292;1;#e27373;2;#94b979;3;#ffba7b;4;#97bedc;5;#e1c0fa;6;#00988e;7;#dedede;8;#bdbdbd;9;#ffa1a1;10;#bddeab;11;#ffdca0;12;#b1d8f6;13;#fbdaff;14;#1ab2a8;15;#ffffff\007"
printf "\033]10;#dedede;#121212;#ffa560\007"
printf "\033]17;#474e91\007"
printf "\033]19;#f4f4f4\007"
printf "\033]5;0;#ffffff\007"
