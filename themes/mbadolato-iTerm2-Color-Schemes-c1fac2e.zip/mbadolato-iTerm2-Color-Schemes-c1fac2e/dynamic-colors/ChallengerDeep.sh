#!/bin/sh
# ChallengerDeep
printf "\033]4;0;#141228;1;#ff5458;2;#62d196;3;#ffb378;4;#65b2ff;5;#906cff;6;#63f2f1;7;#a6b3cc;8;#565575;9;#ff8080;10;#95ffa4;11;#ffe9aa;12;#91ddff;13;#c991e1;14;#aaffe4;15;#cbe3e7\007"
printf "\033]10;#cbe1e7;#1e1c31;#fbfcfc\007"
printf "\033]17;#cbe1e7\007"
printf "\033]19;#1e1c31\007"
printf "\033]5;0;#b6e6f7\007"
